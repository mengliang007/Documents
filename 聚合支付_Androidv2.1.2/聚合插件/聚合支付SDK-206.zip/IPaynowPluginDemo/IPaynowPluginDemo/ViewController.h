//
//  ViewController.h
//  IPaynowPluginSDK
//
//  Created by 黄睿 on 2016/8/4.
//  Copyright © 2016年 iPayNow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

