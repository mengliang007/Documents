//
//  UIViewController+FindTop.h
//  BaiduWallet_Portal
//
//  Created by baidu on 15/7/31.
//  Copyright (c) 2015年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (FindTop)
- (UIViewController*) baiduWalletSchemeTopRootViewController;
@end
